import json

def lambda_handler(event, context):
    # Extract the name from the event if provided; otherwise use "World"
    print(f"{event=}\n\n{context=}")
    
    payload = json.loads(event['Records'][0]['body'])
    print(f"{payload=}")
    name = payload.get('name', 'World')
    
    # Create a greeting message
    greeting = f"Hello, {name}!"
    
    # Log the greeting
    print(greeting)
    
    # Return a response
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": greeting
        })
    }

