import json

def lambda_handler(event, context):
    # Extract the name from the event if provided; otherwise use "World"
    name = event.get('name', 'World')
    
    # Create a greeting message
    greeting = f"Hello, {name}!"
    
    # Log the greeting
    print(greeting)
    
    # Return a response
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": greeting
        })
    }

